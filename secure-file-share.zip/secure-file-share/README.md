
---

## 🧠 2️⃣ `SECURITY_OVERVIEW.md` (create this in your project folder)

```markdown
# 🧾 Security Overview – Secure File Sharing System

## 🔑 1. Encryption Overview
This project uses **AES-256 (Advanced Encryption Standard)** in **CBC (Cipher Block Chaining)** mode.  
Each file is encrypted using a randomly generated 16-byte IV (Initialization Vector), ensuring the same file will produce a different ciphertext each time.

---

## 🧩 2. Key Management
- The AES key (256-bit) is generated once and stored in `/keys/aes.key`.
- The key is not exposed in the repository or logs.
- If the key file doesn’t exist, it’s automatically created using `get_random_bytes(32)`.
- Future improvement: store key in environment variables or use a Key Vault (e.g., AWS KMS, HashiCorp Vault).

---

## 🔐 3. Encryption Flow
1. User uploads a file.  
2. The system reads the file bytes.  
3. Data is padded to match AES block size (16 bytes).  
4. The file is encrypted using AES-256 CBC mode.  
5. The IV is prepended to the encrypted file.  
6. The original plaintext file is deleted.  

Decryption reverses the process using the stored key and IV.

---

## 🛡️ 4. Security Measures
| Risk | Mitigation |
|------|-------------|
| Unencrypted files on disk | Deleted immediately after encryption |
| Key exposure | Stored securely in non-tracked `/keys/` directory |
| File tampering | Encrypted data integrity checked manually |
| Unauthorized access | Flask routes restrict sensitive operations |
| Data leakage | Files encrypted before being stored |

---

## 🧪 5. Security Testing
| Test | Expected Result |
|------|-----------------|
| Upload and download produce identical files | ✅ Success |
| Encrypted file unreadable in text editor | ✅ Success |
| Key file not included in `.gitignore` | ✅ Success |
| Tampered `.enc` file fails to decrypt properly | ✅ Success |

---

## 🧭 6. Improvements (Future Work)
- Password-based key derivation (PBKDF2)
- User authentication (Flask-Login)
- Secure HTTPS using SSL
- Key rotation and expiry
- Database integration for user uploads
- File integrity checks (SHA-256)

---

## 🧍 Author
**Your Name**  
Cybersecurity Intern  
📧 your.email@example.com  
📅 Date: *(fill this in when submitting)*
