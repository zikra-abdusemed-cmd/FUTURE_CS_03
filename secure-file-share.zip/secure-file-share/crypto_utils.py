from Crypto.Cipher import AES
from Crypto.Random import get_random_bytes
import os

KEY_FILE = "keys/aes.key"

def get_aes_key():
    # Generate a new key if it doesn't exist
    if not os.path.exists(KEY_FILE):
        key = get_random_bytes(32)  # AES-256
        with open(KEY_FILE, "wb") as f:
            f.write(key)
    else:
        with open(KEY_FILE, "rb") as f:
            key = f.read()
    return key

def pad(data):
    padding_length = AES.block_size - len(data) % AES.block_size
    return data + bytes([padding_length]) * padding_length

def unpad(data):
    return data[:-data[-1]]

def encrypt_file(filepath):
    key = get_aes_key()
    cipher = AES.new(key, AES.MODE_CBC)
    with open(filepath, "rb") as f:
        plaintext = f.read()
    ciphertext = cipher.encrypt(pad(plaintext))
    encrypted_path = filepath + ".enc"
    with open(encrypted_path, "wb") as f:
        f.write(cipher.iv + ciphertext)
    return encrypted_path

def decrypt_file(encrypted_path):
    key = get_aes_key()
    with open(encrypted_path, "rb") as f:
        iv = f.read(16)
        ciphertext = f.read()
    cipher = AES.new(key, AES.MODE_CBC, iv)
    plaintext = unpad(cipher.decrypt(ciphertext))
    decrypted_path = encrypted_path.replace(".enc", ".dec")
    with open(decrypted_path, "wb") as f:
        f.write(plaintext)
    return decrypted_path
